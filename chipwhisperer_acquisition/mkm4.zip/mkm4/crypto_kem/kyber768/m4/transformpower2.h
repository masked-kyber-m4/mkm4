#ifndef TRANSFORMPOWER2_H
#define TRANSFORMPOWER2_H

#include "masked.h"
#include "masked-poly.h"

masked_coeff_pow2 transformpower2(masked_coeff_q x);

#endif /* TRANSFORMPOWER2_H */