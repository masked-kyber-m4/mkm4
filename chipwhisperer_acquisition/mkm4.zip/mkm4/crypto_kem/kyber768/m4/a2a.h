#ifndef A2A__H
#define A2A__H

void A2A_reset(void);
void A2A_C_A_13_1(int16_t *a, int16_t *b);

#endif 
